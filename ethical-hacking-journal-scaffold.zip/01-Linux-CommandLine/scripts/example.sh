#!/usr/bin/env bash
# example script placeholder
echo "Hello from linux scripts"
