# ROADMAP (starter)

## Phase 0 - Setup
- WSL, VS Code, initial packages

## Phase 1 - Foundations (21 days)
- Linux CLI, Bandit, scripts

## Phase 2 - Networking
- nmap, tcpdump, wireshark

(expand as you progress)
