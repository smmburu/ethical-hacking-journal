# 00-Setup Notes

Document OS, WSL setup, virtualization, and initial configuration steps here.

- Distro: Ubuntu 24.04 on WSL2
- VS Code Remote - WSL setup
- Installed packages: git, nmap, tcpdump, python3, vim
