# Example TryHackMe Room Writeup

