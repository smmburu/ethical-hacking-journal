# Books

- Kali Linux Revealed
