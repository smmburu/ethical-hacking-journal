# YouTube Resources

- NetworkChuck
- The Cyber Mentor
